import { useState, useEffect, useMemo, useRef } from 'react';
import { Activity, Search, Package, TrendingUp, RefreshCw, X, BarChart3, PieChart as PieChartIcon, LayoutDashboard, Terminal, Database, Play } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  LineChart, Line, PieChart, Pie, Cell, ComposedChart, AreaChart, Area,
  ScatterChart, Scatter, ZAxis
} from 'recharts';
import { api } from './api';
import type { Product, Stats, Task } from './api';

// --- Terminal Typing Effect Component ---
const TerminalLog = ({ text }: { text: string }) => {
  const [displayed, setDisplayed] = useState('');
  
  useEffect(() => {
    if (!text) return;
    
    // Only type the new part to preserve the illusion of a continuous stream
    if (text.startsWith(displayed)) {
      const remaining = text.slice(displayed.length);
      if (remaining.length === 0) return;
      
      let i = 0;
      const interval = setInterval(() => {
        if (i < remaining.length) {
          setDisplayed(prev => prev + remaining.charAt(i));
          i++;
        } else {
          clearInterval(interval);
        }
      }, 15); // Fast typing speed (15ms per char)
      return () => clearInterval(interval);
    } else {
      // Fallback if the text completely changed
      setDisplayed(text);
    }
  }, [text, displayed]);

  return (
    <div style={{
      padding: '1rem', background: '#0a0c10', borderRadius: '8px',
      fontFamily: '"Fira Code", Consolas, monospace', fontSize: '0.85rem', color: '#34d399', whiteSpace: 'pre-wrap',
      border: '1px solid #1f2937', boxShadow: 'inset 0 2px 10px rgba(0,0,0,0.5)',
      lineHeight: '1.5'
    }}>
      {displayed}
      <span className="blinking-cursor">█</span>
    </div>
  );
};

// Recharts colors (macOS Cyberpunk aesthetic)
const COLORS = [
  '#60a5fa', // Blue
  '#34d399', // Emerald
  '#fbbf24', // Amber
  '#a78bfa', // Purple
  '#f87171', // Red
  '#2dd4bf', // Teal
  '#f472b6', // Pink
  '#94a3b8'  // Slate (for Others)
];

// Custom Tooltip for dark mode
const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div style={{ background: 'rgba(15, 17, 26, 0.9)', border: '1px solid rgba(255,255,255,0.1)', padding: '12px', borderRadius: '12px', backdropFilter: 'blur(10px)' }}>
        <p style={{ margin: '0 0 8px 0', fontWeight: 600, color: '#f8fafc' }}>{label}</p>
        {payload.map((entry: any, index: number) => (
          <p key={index} style={{ margin: 0, color: entry.color, fontSize: '0.875rem' }}>
            {entry.name}: <span style={{ fontWeight: 600 }}>{entry.value}</span>
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'overview' | 'scraper' | 'database'>('overview');
  
  const [stats, setStats] = useState<Stats | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterText, setFilterText] = useState(''); 
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedSkus, setSelectedSkus] = useState<Set<string>>(new Set());
  const [scraping, setScraping] = useState(false);
  const [scrapePages, setScrapePages] = useState(1); // 抓取深度页数
  const [sortConfig, setSortConfig] = useState<{key: 'price' | 'review_count' | null, direction: 'asc' | 'desc'}>({key: 'review_count', direction: 'desc'});
  const [waitingForLog, setWaitingForLog] = useState(false);
  const terminalRef = useRef<HTMLDivElement>(null);
  
  // Modal state for Price Trend
  const [selectedSku, setSelectedSku] = useState<string | null>(null);
  const [priceHistory, setPriceHistory] = useState<any[]>([]);

  const fetchData = async (silent = false) => {
    try {
      if (!silent) setLoading(true);
      const [statsRes, prodRes, taskRes] = await Promise.all([
        api.get<Stats>('/products/stats'),
        api.get<Product[]>('/products/?limit=1000'), // Fetch up to 1000 for better local filtering
        api.get<Task[]>('/tasks/?limit=20')
      ]);
      setStats(statsRes.data);
      setProducts(prodRes.data);
      setTasks(taskRes.data);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      if (!silent) setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(() => {
      fetchData(true);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleScrape = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    try {
      setScraping(true);
      setWaitingForLog(true);
      
      // 触发平滑滚动到终端区域
      setTimeout(() => {
        terminalRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 100);

      await api.post('/tasks/search', {
        task_type: 'SEARCH',
        query: searchQuery,
        country: 'uae',
        language: 'en',
        pages: scrapePages
      });
      setSearchQuery('');
      fetchData(true);
    } catch (error) {
      console.error('Scraping failed:', error);
      alert('Failed to start scraping task.');
    } finally {
      setScraping(false);
      // 保证一定能解除锁定
      setTimeout(() => setWaitingForLog(false), 1500);
    }
  };

  // 监听任务状态，如果有正在跑的任务，可以立即解除锁定
  useEffect(() => {
    const activeTask = tasks.find(t => t.status === 'RUNNING');
    if (waitingForLog && activeTask) {
      setWaitingForLog(false);
    }
  }, [tasks, waitingForLog]);

  const openPriceTrend = async (sku: string) => {
    setSelectedSku(sku);
    setPriceHistory([]);
    try {
      const safeSku = encodeURIComponent(sku);
      const res = await api.get(`/products/${safeSku}/prices`);
      const formatted = res.data.map((item: any) => {
        const date = new Date(item.scraped_at);
        return {
          time: `${date.getHours()}:${date.getMinutes().toString().padStart(2, '0')}:${date.getSeconds().toString().padStart(2, '0')}`,
          price: item.price,
          original_price: item.original_price,
          review_count: item.review_count || 0
        };
      });
      setPriceHistory(formatted);
    } catch (e) {
      console.error(e);
    }
  };

  const handleBatchDelete = async () => {
    if (selectedSkus.size === 0) return;
    if (!confirm(`确定要将选中的 ${selectedSkus.size} 个商品移出监控池吗？(大盘将不再统计其数据)`)) return;
    
    try {
      await Promise.all(
        Array.from(selectedSkus).map(sku => api.delete(`/products/${encodeURIComponent(sku)}`))
      );
      // Remove from local state immediately for fast UI feedback
      setProducts(products.filter(p => !selectedSkus.has(p.sku)));
      setSelectedSkus(new Set());
    } catch (e) {
      console.error('Batch delete failed', e);
      alert('部分删除失败，请检查控制台。');
    }
  };

  // ── Data Processing for Charts & Categories ──
  
  // Extract unique successful queries as implicit product categories
  const categoryTabs = useMemo(() => {
    const queries = new Set<string>();
    tasks.forEach(t => {
      if (t.status === 'SUCCESS' && t.query && !t.query.startsWith('OFFER_')) {
        queries.add(t.query.toLowerCase());
      }
    });
    return Array.from(queries);
  }, [tasks]);

  const filteredProducts = useMemo(() => {
    let result = products;
    
    // Apply Tab Category Filter
    if (selectedCategory !== 'All') {
      const q = selectedCategory.toLowerCase();
      result = result.filter(p => 
        (p.title && p.title.toLowerCase().includes(q)) || 
        (p.brand && p.brand.toLowerCase().includes(q)) ||
        (p.category && p.category.toLowerCase().includes(q))
      );
    }
    
    // Apply Text Search Filter
    if (filterText.trim()) {
      const lowerFilter = filterText.toLowerCase();
      result = result.filter(p => 
        (p.title && p.title.toLowerCase().includes(lowerFilter)) || 
        (p.brand && p.brand.toLowerCase().includes(lowerFilter)) ||
        (p.category && p.category.toLowerCase().includes(lowerFilter))
      );
    }
    
    // Apply Sorting
    if (sortConfig.key) {
      result.sort((a, b) => {
        const valA = a[sortConfig.key as keyof Product] || 0;
        const valB = b[sortConfig.key as keyof Product] || 0;
        if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
        if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }
    
    return result;
  }, [products, filterText, selectedCategory, sortConfig]);

  const priceDistribution = useMemo(() => {
    if (!filteredProducts.length) return [];
    
    const prices = filteredProducts
      .map(p => p.price)
      .filter((price): price is number => price !== null && price !== undefined && price > 0)
      .sort((a, b) => a - b);
      
    if (prices.length === 0) return [];

    let minPrice = prices[0];
    let maxPrice = prices[prices.length - 1];

    if (prices.length > 4) {
      const q1 = prices[Math.floor(prices.length * 0.25)];
      const q3 = prices[Math.floor(prices.length * 0.75)];
      const iqr = q3 - q1;
      const lowerBound = Math.max(0, q1 - 1.5 * iqr);
      const upperBound = q3 + 1.5 * iqr;
      
      const validPrices = prices.filter(p => p >= lowerBound && p <= upperBound);
      if (validPrices.length > 0) {
        minPrice = validPrices[0];
        maxPrice = validPrices[validPrices.length - 1];
      }
    }

    if (minPrice === Infinity || minPrice === maxPrice) {
      return [{ name: `${minPrice || 0}`, productCount: products.length, totalReviews: 0 }];
    }

    const bucketCount = 12;
    const interval = (maxPrice - minPrice + 0.01) / bucketCount; 
    
    const bucketsProductCount = Array(bucketCount).fill(0);
    const bucketsReviewCount = Array(bucketCount).fill(0);
    const bucketLabels = Array(bucketCount).fill('');

    for (let i = 0; i < bucketCount; i++) {
      const start = Math.floor(minPrice + i * interval);
      const end = i === bucketCount - 1 ? Math.ceil(maxPrice) : Math.floor(minPrice + (i + 1) * interval - 1);
      bucketLabels[i] = `${start}-${end}`;
    }

    filteredProducts.forEach(p => {
      const price = p.price;
      const reviews = p.review_count || 0;
      if (price !== null && price !== undefined && price >= minPrice && price <= maxPrice) {
        const index = Math.floor((price - minPrice) / interval);
        const safeIndex = Math.min(Math.max(index, 0), bucketCount - 1);
        bucketsProductCount[safeIndex]++;
        bucketsReviewCount[safeIndex] += reviews;
      }
    });

    return bucketLabels.map((label, i) => ({
      name: label,
      productCount: bucketsProductCount[i],
      totalReviews: bucketsReviewCount[i]
    })).filter(d => d.productCount > 0); 
  }, [filteredProducts]);

  const salesDistribution = useMemo(() => {
    if (!filteredProducts.length) return [];
    
    const bins = [
      { max: 50, label: '0-50' },
      { max: 150, label: '50-150' },
      { max: 400, label: '150-400' },
      { max: 1000, label: '400-1k' },
      { max: 3000, label: '1k-3k' },
      { max: 10000, label: '3k-1w' },
      { max: Infinity, label: '1w+' }
    ];
    
    const counts = new Array(bins.length).fill(0);
    
    filteredProducts.forEach(p => {
      // 综合销量估算模型 = (评论数 * 转化放大系数) + (低价冲量加成) + (评分加成)
      const baseReviews = (p.review_count || 0) * 38;
      const priceFactor = 1500 / Math.max(p.price || 1, 10);
      const ratingFactor = (p.rating || 3.5) * 20;
      const estimatedSales = Math.floor(baseReviews + priceFactor + ratingFactor);
      
      for (let i = 0; i < bins.length; i++) {
        if (estimatedSales <= bins[i].max) {
          counts[i]++;
          break;
        }
      }
    });
    
    return bins.map((bin, i) => ({
      name: bin.label,
      value: counts[i]
    }));
  }, [filteredProducts]);

  // Dynamic stats based on selected category
  const dynamicStats = useMemo(() => {
    if (selectedCategory === 'All') return stats;
    return {
      total_products: filteredProducts.length,
      active_products: filteredProducts.filter(p => p.price !== null).length,
      total_snapshots: filteredProducts.reduce((sum, p) => sum + (p.review_count || 0), 0)
    };
  }, [filteredProducts, selectedCategory, stats]);

  // 价格 vs 评论数 散点图数据
  const scatterData = useMemo(() => {
    return filteredProducts
      .filter(p => p.price != null && p.price > 0)
      .map(p => ({
        name: (p.title || '').slice(0, 20),
        price: p.price,
        reviews: p.review_count || 0,
        rating: p.rating || 0,
      }));
  }, [filteredProducts]);

  // 品牌竞争力 TOP10
  const brandRanking = useMemo(() => {
    if (!filteredProducts.length) return [];
    const brandMap: Record<string, { count: number; totalReviews: number; totalRating: number; ratedCount: number }> = {};

    filteredProducts.forEach(p => {
      const brand = (p.brand || '').toUpperCase().trim() || '白牌';
      if (!brandMap[brand]) brandMap[brand] = { count: 0, totalReviews: 0, totalRating: 0, ratedCount: 0 };
      brandMap[brand].count++;
      brandMap[brand].totalReviews += (p.review_count || 0);
      if (p.rating) {
        brandMap[brand].totalRating += p.rating;
        brandMap[brand].ratedCount++;
      }
    });

    return Object.entries(brandMap)
      .map(([name, d]) => ({
        name: name.length > 12 ? name.slice(0, 12) + '…' : name,
        商品数: d.count,
        总评论: d.totalReviews,
        均分: d.ratedCount > 0 ? Math.round(d.totalRating / d.ratedCount * 10) / 10 : 0,
      }))
      .sort((a, b) => b.总评论 - a.总评论)
      .slice(0, 10);
  }, [filteredProducts]);

  return (
    <div className="app-container">
      {/* Animated Mesh Gradient Background */}
      <div className="app-background"></div>

      {/* Sidebar Navigation */}
      <aside className="sidebar">
        <div className="sidebar-logo">
          <Activity size={28} color="var(--primary)" />
          <span>NOON Base</span>
        </div>

        <nav className="nav-menu">
          <div className={`nav-item ${activeTab === 'overview' ? 'active' : ''}`} onClick={() => setActiveTab('overview')}>
            <LayoutDashboard size={20} />
            <span>大盘总览 (Overview)</span>
          </div>
          <div className={`nav-item ${activeTab === 'scraper' ? 'active' : ''}`} onClick={() => setActiveTab('scraper')}>
            <Terminal size={20} />
            <span>爬虫控制 (Scraper)</span>
          </div>
          <div className={`nav-item ${activeTab === 'database' ? 'active' : ''}`} onClick={() => setActiveTab('database')}>
            <Database size={20} />
            <span>商品库 (Database)</span>
          </div>
        </nav>
        
        <div style={{ marginTop: 'auto', padding: '1rem', background: 'rgba(255,255,255,0.02)', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.05)' }}>
          <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Status</p>
          <div className="flex items-center gap-2" style={{ marginTop: '0.25rem' }}>
            <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: 'var(--success)', boxShadow: '0 0 10px var(--success)' }}></span>
            <span style={{ fontSize: '0.875rem', fontWeight: 500 }}>System Online</span>
          </div>
        </div>
      </aside>

      {/* Main Content Workspace */}
      <main className="main-content">
        <AnimatePresence mode="wait">
          
          {/* ===================== OVERVIEW TAB ===================== */}
          {activeTab === 'overview' && (
            <motion.div key="overview" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
              <div className="flex justify-between items-center" style={{ marginBottom: '1.5rem' }}>
                <div>
                  <h1>市场分析大盘</h1>
                  <p style={{ color: 'var(--text-muted)' }}>您的实时电商洞察指挥中心</p>
                </div>
                <div style={{ position: 'relative', width: '300px' }}>
                  <Search size={16} style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                  <input 
                    type="text" 
                    className="input" 
                    placeholder="过滤特定商品 (如 massage gun)..." 
                    style={{ paddingLeft: '2.5rem', borderRadius: '20px', background: 'var(--panel-bg)', border: '1px solid var(--panel-border)' }}
                    value={filterText}
                    onChange={(e) => setFilterText(e.target.value)}
                  />
                </div>
              </div>

              {/* Category Horizontal Tabs */}
              <div className="flex gap-2" style={{ marginBottom: '1.5rem', overflowX: 'auto', paddingBottom: '0.5rem', WebkitOverflowScrolling: 'touch' }}>
                <button 
                  onClick={() => setSelectedCategory('All')} 
                  style={{ 
                    padding: '0.5rem 1.25rem', borderRadius: '20px', border: '1px solid var(--panel-border)',
                    background: selectedCategory === 'All' ? 'var(--primary)' : 'rgba(255,255,255,0.03)', 
                    color: selectedCategory === 'All' ? 'white' : 'var(--text-muted)', 
                    cursor: 'pointer', whiteSpace: 'nowrap', fontWeight: 500, transition: 'all 0.2s', backdropFilter: 'blur(10px)'
                  }}
                >
                  大盘总览 (All)
                </button>
                {categoryTabs.map(q => (
                  <button 
                    key={q} 
                    onClick={() => setSelectedCategory(q)} 
                    style={{ 
                      padding: '0.5rem 1.25rem', borderRadius: '20px', border: '1px solid var(--panel-border)',
                      background: selectedCategory === q ? 'var(--primary)' : 'rgba(255,255,255,0.03)', 
                      color: selectedCategory === q ? 'white' : 'var(--text-muted)', 
                      cursor: 'pointer', whiteSpace: 'nowrap', textTransform: 'capitalize', fontWeight: 500, transition: 'all 0.2s', backdropFilter: 'blur(10px)'
                    }}
                  >
                    {q}
                  </button>
                ))}
              </div>

              {/* Bento Grid Stats */}
              <div className="bento-grid" style={{ marginBottom: '1.5rem' }}>
                <div className="glass-panel bento-col-4" style={{ padding: '1.5rem' }}>
                  <div className="flex items-center gap-4">
                    <div style={{ background: 'rgba(96, 165, 250, 0.1)', padding: '1rem', borderRadius: '1rem' }}>
                      <Package color="var(--primary)" size={24} />
                    </div>
                    <div>
                      <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', fontWeight: 500 }}>{selectedCategory !== 'All' ? '该品类收录数' : '总收录商品数'}</p>
                      <h2 style={{ fontSize: '2rem', margin: 0 }}>{dynamicStats?.total_products || 0}</h2>
                    </div>
                  </div>
                </div>
                
                <div className="glass-panel bento-col-4" style={{ padding: '1.5rem' }}>
                  <div className="flex items-center gap-4">
                    <div style={{ background: 'rgba(52, 211, 153, 0.1)', padding: '1rem', borderRadius: '1rem' }}>
                      <TrendingUp color="var(--success)" size={24} />
                    </div>
                    <div>
                      <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', fontWeight: 500 }}>有效在售/活跃</p>
                      <h2 style={{ fontSize: '2rem', margin: 0 }}>{dynamicStats?.active_products || 0}</h2>
                    </div>
                  </div>
                </div>

                <div className="glass-panel bento-col-4" style={{ padding: '1.5rem' }}>
                  <div className="flex items-center gap-4">
                    <div style={{ background: 'rgba(167, 139, 250, 0.1)', padding: '1rem', borderRadius: '1rem' }}>
                      <Activity color="#a78bfa" size={24} />
                    </div>
                    <div>
                      <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', fontWeight: 500 }}>总销售热度 (预估)</p>
                      <h2 style={{ fontSize: '2rem', margin: 0 }}>{dynamicStats?.total_snapshots || 0}</h2>
                    </div>
                  </div>
                </div>
              </div>

              {/* Charts Bento */}
              <div className="bento-grid">
                <div className="glass-panel bento-col-8" style={{ padding: '1.5rem' }}>
                  <h3 className="flex items-center gap-2" style={{ marginBottom: '1.5rem' }}><BarChart3 size={20} color="var(--primary)" /> 蓝海价格段分析 <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>(价格单位: AED, 柱条=商品数, 折线=总评论数)</span></h3>
                  <div style={{ height: '300px', width: '100%' }}>
                    {priceDistribution.length > 0 ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <ComposedChart data={priceDistribution} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                          <XAxis dataKey="name" stroke="#a1a1aa" fontSize={11} tickLine={false} axisLine={false} />
                          <YAxis yAxisId="left" stroke="#60a5fa" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
                          <YAxis yAxisId="right" orientation="right" stroke="#34d399" fontSize={11} tickLine={false} axisLine={false} />
                          <Tooltip content={<CustomTooltip />} />
                          <Bar yAxisId="left" dataKey="productCount" name="商品数(竞争)" fill="var(--primary)" radius={[4, 4, 0, 0]} barSize={24} opacity={0.8} />
                          <Line yAxisId="right" type="monotone" dataKey="totalReviews" name="总评论(需求)" stroke="var(--success)" strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                        </ComposedChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="flex items-center" style={{ height: '100%', justifyContent: 'center', color: 'var(--text-muted)' }}>暂无分析数据</div>
                    )}
                  </div>
                </div>

                <div className="glass-panel bento-col-4" style={{ padding: '1.5rem' }}>
                  <h3 className="flex items-center gap-2" style={{ marginBottom: '1.5rem' }}><TrendingUp size={20} color="#a78bfa" /> 预估销量大盘分布 <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>(X轴: 预估销量/件, Y轴: 商品数/个)</span></h3>
                  <div style={{ height: '300px', width: '100%' }}>
                    {salesDistribution.length > 0 ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={salesDistribution} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                          <defs>
                            <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#a78bfa" stopOpacity={0.8}/>
                              <stop offset="95%" stopColor="#a78bfa" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                          <XAxis dataKey="name" stroke="#a1a1aa" fontSize={11} tickLine={false} axisLine={false} />
                          <YAxis stroke="#a1a1aa" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
                          <Tooltip content={<CustomTooltip />} />
                          <Area type="monotone" dataKey="value" name="商品数" stroke="#a78bfa" fillOpacity={1} fill="url(#colorSales)" />
                        </AreaChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="flex items-center" style={{ height: '100%', justifyContent: 'center', color: 'var(--text-muted)' }}>暂无销量数据</div>
                    )}
                  </div>
                </div>
              </div>

              {/* Charts Row 2: Scatter + Brand Ranking */}
              <div className="bento-grid" style={{ marginTop: '1.5rem' }}>
                <div className="glass-panel bento-col-6" style={{ padding: '1.5rem' }}>
                  <h3 className="flex items-center gap-2" style={{ marginBottom: '1.5rem' }}><Activity size={20} color="#f59e0b" /> 价格 vs 评论数 <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>(X轴: 价格/AED, Y轴: 评论数/条, 气泡大小=评分)</span></h3>
                  <div style={{ height: '320px', width: '100%' }}>
                    {scatterData.length > 0 ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <ScatterChart margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                          <XAxis type="number" dataKey="price" name="价格" unit=" AED" stroke="#a1a1aa" fontSize={11} tickLine={false} axisLine={false} />
                          <YAxis type="number" dataKey="reviews" name="评论数" stroke="#a1a1aa" fontSize={11} tickLine={false} axisLine={false} />
                          <ZAxis type="number" dataKey="rating" range={[30, 200]} name="评分" />
                          <Tooltip
                            cursor={{ strokeDasharray: '3 3' }}
                            content={({ active, payload }: any) => {
                              if (!active || !payload?.length) return null;
                              const d = payload[0].payload;
                              return (
                                <div style={{ background: 'rgba(15,17,25,0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', padding: '0.75rem 1rem', fontSize: '0.8rem' }}>
                                  <p style={{ fontWeight: 600, marginBottom: '0.25rem' }}>{d.name}</p>
                                  <p style={{ color: '#f59e0b' }}>价格: {d.price} AED</p>
                                  <p style={{ color: '#34d399' }}>评论数: {d.reviews}</p>
                                  <p style={{ color: '#a78bfa' }}>评分: {d.rating || '无'}</p>
                                </div>
                              );
                            }}
                          />
                          <Scatter name="商品" data={scatterData} fill="#f59e0b" fillOpacity={0.6} />
                        </ScatterChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="flex items-center" style={{ height: '100%', justifyContent: 'center', color: 'var(--text-muted)' }}>暂无数据</div>
                    )}
                  </div>
                </div>

                <div className="glass-panel bento-col-6" style={{ padding: '1.5rem' }}>
                  <h3 className="flex items-center gap-2" style={{ marginBottom: '1.5rem' }}><BarChart3 size={20} color="#34d399" /> 品牌竞争力 TOP10 <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>(按总评论数排名, 柱条=总评论, 标签=商品数)</span></h3>
                  <div style={{ height: '320px', width: '100%' }}>
                    {brandRanking.length > 0 ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={brandRanking} layout="vertical" margin={{ top: 5, right: 30, left: 10, bottom: 5 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" horizontal={false} />
                          <XAxis type="number" stroke="#a1a1aa" fontSize={11} tickLine={false} axisLine={false} />
                          <YAxis type="category" dataKey="name" stroke="#a1a1aa" fontSize={11} tickLine={false} axisLine={false} width={100} />
                          <Tooltip
                            content={({ active, payload }: any) => {
                              if (!active || !payload?.length) return null;
                              const d = payload[0].payload;
                              return (
                                <div style={{ background: 'rgba(15,17,25,0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', padding: '0.75rem 1rem', fontSize: '0.8rem' }}>
                                  <p style={{ fontWeight: 600, marginBottom: '0.25rem' }}>{d.name}</p>
                                  <p style={{ color: '#34d399' }}>总评论: {d.总评论}</p>
                                  <p style={{ color: '#60a5fa' }}>商品数: {d.商品数} 个</p>
                                  <p style={{ color: '#f59e0b' }}>平均评分: {d.均分 || '无'}</p>
                                </div>
                              );
                            }}
                          />
                          <Bar dataKey="总评论" fill="url(#brandGradient)" radius={[0, 6, 6, 0]} barSize={18} />
                          <defs>
                            <linearGradient id="brandGradient" x1="0" y1="0" x2="1" y2="0">
                              <stop offset="0%" stopColor="#34d399" stopOpacity={0.4}/>
                              <stop offset="100%" stopColor="#34d399" stopOpacity={1}/>
                            </linearGradient>
                          </defs>
                        </BarChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="flex items-center" style={{ height: '100%', justifyContent: 'center', color: 'var(--text-muted)' }}>暂无品牌数据</div>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* ===================== SCRAPER TAB ===================== */}
          {activeTab === 'scraper' && (
            <motion.div key="scraper" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
              <h1>爬虫控制中心</h1>
              <p style={{ color: 'var(--text-muted)', marginBottom: '2rem' }}>在这里发起实时抓取任务，数据经过智能清洗后会自动进入大盘。</p>
              
              <div className="bento-grid">
                <div className="glass-panel bento-col-12" style={{ padding: '3rem', textAlign: 'center', background: 'rgba(25, 28, 41, 0.7)' }}>
                  <form onSubmit={handleScrape} className="flex gap-4" style={{ maxWidth: '700px', margin: '0 auto' }}>
                    <div style={{ position: 'relative', flex: 1 }}>
                      <Search size={20} style={{ position: 'absolute', left: '1.25rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                      <input 
                        type="text" 
                        className="input" 
                        placeholder="输入商品关键词进行竞速抓取 (如 massage gun)..." 
                        style={{ paddingLeft: '3rem', paddingRight: '1rem', paddingTop: '1rem', paddingBottom: '1rem', fontSize: '1.1rem', borderRadius: '16px' }}
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        disabled={scraping || waitingForLog}
                      />
                    </div>
                    
                    <select 
                      className="input"
                      value={scrapePages}
                      onChange={(e) => setScrapePages(Number(e.target.value))}
                      disabled={scraping || waitingForLog}
                      style={{ width: '120px', borderRadius: '16px', background: 'var(--panel-bg)', color: 'white', padding: '0 1rem', cursor: 'pointer' }}
                    >
                      <option value={1}>抓 1 页</option>
                      <option value={3}>抓 3 页</option>
                      <option value={5}>抓 5 页</option>
                      <option value={10}>抓 10 页</option>
                    </select>

                    <button type="submit" className="btn" disabled={scraping || waitingForLog} style={{ padding: '0 2rem', borderRadius: '16px', whiteSpace: 'nowrap' }}>
                      {(scraping || waitingForLog) ? <RefreshCw className="spin" size={20} /> : <><Play size={20} /> 执行抓取</>}
                      {waitingForLog && <span style={{marginLeft: '0.5rem'}}>引擎启动中...</span>}
                    </button>
                  </form>
                </div>

                <div ref={terminalRef} className="glass-panel bento-col-12" style={{ padding: '1.5rem', maxHeight: '500px', display: 'flex', flexDirection: 'column' }}>
                  <h3 style={{ marginBottom: '1.5rem' }}>实时任务日志终端</h3>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', overflowY: 'auto' }}>
                    <AnimatePresence>
                      {tasks.map((task, i) => (
                        <motion.div 
                          key={task.job_id}
                          initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
                          style={{ background: 'rgba(0,0,0,0.3)', padding: '1.25rem', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.05)' }}
                        >
                          <div className="flex justify-between items-center" style={{ marginBottom: '0.75rem' }}>
                            <span style={{ fontWeight: 600, fontSize: '1.1rem' }}>{task.query}</span>
                            <span style={{ 
                              padding: '0.25rem 0.75rem', borderRadius: '20px', fontSize: '0.75rem', fontWeight: 600,
                              background: task.status === 'SUCCESS' ? 'rgba(52, 211, 153, 0.2)' : task.status === 'FAILED' ? 'rgba(248, 113, 113, 0.2)' : 'rgba(251, 191, 36, 0.2)',
                              color: task.status === 'SUCCESS' ? 'var(--success)' : task.status === 'FAILED' ? 'var(--danger)' : '#fbbf24'
                            }}>
                              {task.status}
                            </span>
                          </div>
                          
                          {task.error_message ? (
                            <TerminalLog text={task.error_message} />
                          ) : (
                            <div style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>
                              入库商品数: {task.result_count !== null ? task.result_count : '等待中...'}
                            </div>
                          )}
                        </motion.div>
                      ))}
                    </AnimatePresence>
                    {tasks.length === 0 && (
                      <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>暂无任务日志</div>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* ===================== DATABASE TAB ===================== */}
          {activeTab === 'database' && (
            <motion.div key="database" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
              <div className="flex justify-between items-center" style={{ marginBottom: '1.5rem' }}>
                <div>
                  <h1>追踪商品库 ({filteredProducts.length} 件)</h1>
                  <p style={{ color: 'var(--text-muted)' }}>已清洗入库的所有商品列表（点击可查看单品趋势）</p>
                </div>
              </div>
              
              {/* Category Horizontal Tabs & Batch Actions */}
              <div className="flex justify-between items-center" style={{ marginBottom: '1.5rem' }}>
                <div className="flex gap-2" style={{ overflowX: 'auto', paddingBottom: '0.5rem', WebkitOverflowScrolling: 'touch', flex: 1 }}>
                  <button 
                    onClick={() => setSelectedCategory('All')} 
                    style={{ 
                      padding: '0.5rem 1.25rem', borderRadius: '20px', border: '1px solid var(--panel-border)',
                      background: selectedCategory === 'All' ? 'var(--primary)' : 'rgba(255,255,255,0.03)', 
                      color: selectedCategory === 'All' ? 'white' : 'var(--text-muted)', 
                      cursor: 'pointer', whiteSpace: 'nowrap', fontWeight: 500, transition: 'all 0.2s', backdropFilter: 'blur(10px)'
                    }}
                  >
                    全部 (All)
                  </button>
                  {categoryTabs.map(q => (
                    <button 
                      key={q} 
                      onClick={() => setSelectedCategory(q)} 
                      style={{ 
                        padding: '0.5rem 1.25rem', borderRadius: '20px', border: '1px solid var(--panel-border)',
                        background: selectedCategory === q ? 'var(--primary)' : 'rgba(255,255,255,0.03)', 
                        color: selectedCategory === q ? 'white' : 'var(--text-muted)', 
                        cursor: 'pointer', whiteSpace: 'nowrap', textTransform: 'capitalize', fontWeight: 500, transition: 'all 0.2s', backdropFilter: 'blur(10px)'
                      }}
                    >
                      {q}
                    </button>
                  ))}
                </div>
                
                {selectedSkus.size > 0 && (
                  <button 
                    className="btn btn-danger" 
                    onClick={handleBatchDelete}
                    style={{ background: 'rgba(239, 68, 68, 0.2)', color: '#ef4444', border: '1px solid rgba(239, 68, 68, 0.5)', padding: '0.5rem 1rem', borderRadius: '8px', whiteSpace: 'nowrap', marginLeft: '1rem' }}
                  >
                    移出监控 ({selectedSkus.size})
                  </button>
                )}
              </div>
              
              <div className="glass-panel" style={{ padding: '0', overflow: 'hidden' }}>
                <div style={{ maxHeight: '70vh', overflowY: 'auto' }}>
                  <table>
                    <thead style={{ position: 'sticky', top: 0, background: 'rgba(25, 28, 41, 0.9)', backdropFilter: 'blur(12px)', zIndex: 10 }}>
                      <tr>
                        <th style={{ width: '40px', textAlign: 'center' }}>
                          <input 
                            type="checkbox" 
                            checked={selectedSkus.size > 0 && selectedSkus.size === filteredProducts.length}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedSkus(new Set(filteredProducts.map(p => p.sku)));
                              } else {
                                setSelectedSkus(new Set());
                              }
                            }}
                          />
                        </th>
                        <th style={{ width: '50%' }}>商品信息</th>
                        <th 
                          style={{ cursor: 'pointer', userSelect: 'none' }}
                          onClick={() => {
                            if (sortConfig.key === 'price') {
                              setSortConfig({ key: 'price', direction: sortConfig.direction === 'asc' ? 'desc' : 'asc' });
                            } else {
                              setSortConfig({ key: 'price', direction: 'asc' });
                            }
                          }}
                        >
                          最新价格 {sortConfig.key === 'price' ? (sortConfig.direction === 'asc' ? '↑' : '↓') : '↕'}
                        </th>
                        <th 
                          style={{ cursor: 'pointer', userSelect: 'none' }}
                          onClick={() => {
                            if (sortConfig.key === 'review_count') {
                              setSortConfig({ key: 'review_count', direction: sortConfig.direction === 'asc' ? 'desc' : 'asc' });
                            } else {
                              setSortConfig({ key: 'review_count', direction: 'desc' });
                            }
                          }}
                        >
                          累计评论 (销量) {sortConfig.key === 'review_count' ? (sortConfig.direction === 'asc' ? '↑' : '↓') : '↕'}
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredProducts.map(p => (
                        <tr key={p.sku} onClick={() => openPriceTrend(p.sku)} style={{ cursor: 'pointer' }}>
                          <td style={{ textAlign: 'center' }} onClick={e => e.stopPropagation()}>
                            <input 
                              type="checkbox" 
                              checked={selectedSkus.has(p.sku)}
                              onChange={(e) => {
                                const newSet = new Set(selectedSkus);
                                if (e.target.checked) newSet.add(p.sku);
                                else newSet.delete(p.sku);
                                setSelectedSkus(newSet);
                              }}
                            />
                          </td>
                          <td style={{ padding: '1.25rem 1rem' }}>
                            <div className="flex items-center gap-4">
                              {p.image_url ? (
                                <img src={p.image_url} alt="" style={{ width: '56px', height: '56px', objectFit: 'contain', background: 'white', borderRadius: '8px' }} />
                              ) : (
                                <div style={{ width: '56px', height: '56px', background: 'rgba(0,0,0,0.2)', borderRadius: '8px' }} />
                              )}
                              <div>
                                <div style={{ fontWeight: 500, maxWidth: '400px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                  {p.is_express && <span style={{ padding: '0.15rem 0.3rem', background: '#fbbf24', color: '#000', borderRadius: '4px', fontSize: '0.65rem', fontWeight: 800, marginRight: '0.5rem', verticalAlign: 'middle' }}>EXPRESS</span>}
                                  {p.title}
                                </div>
                                <div className="flex items-center gap-3" style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.35rem' }}>
                                  <span>SKU: {p.sku}</span>
                                  {p.brand && p.brand !== 'UNKNOWN' && (
                                    <>
                                      <span style={{ color: 'rgba(255,255,255,0.2)' }}>|</span>
                                      <span style={{ color: '#a78bfa', fontWeight: 600 }}>{p.brand}</span>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>
                          </td>
                          <td style={{ fontWeight: 700, color: 'var(--primary)', fontSize: '1.1rem' }}>
                            {p.price ? `${p.price} ${p.currency || 'AED'}` : '-'}
                          </td>
                          <td style={{ fontWeight: 700, color: 'var(--success)', fontSize: '1.1rem' }}>
                            {p.review_count !== null ? p.review_count.toLocaleString() : '0'}
                          </td>
                        </tr>
                      ))}
                      {filteredProducts.length === 0 && (
                        <tr>
                          <td colSpan={4} style={{ textAlign: 'center', padding: '4rem', color: 'var(--text-muted)' }}>
                            库中暂无商品
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </main>
      
      {/* Price Trend Modal Overlay */}
      <AnimatePresence>
        {selectedSku && (
          <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="modal-overlay"
            onClick={() => setSelectedSku(null)}
          >
            <motion.div 
              initial={{ scale: 0.95, y: 10, opacity: 0 }} animate={{ scale: 1, y: 0, opacity: 1 }} exit={{ scale: 0.95, y: 10, opacity: 0 }}
              className="modal-content"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-between items-center" style={{ marginBottom: '2rem' }}>
                <div>
                  <h2 style={{ marginBottom: '0.25rem' }}>价格波动趋势</h2>
                  <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>SKU: {selectedSku}</p>
                </div>
                <button 
                  onClick={() => setSelectedSku(null)} 
                  style={{ background: 'rgba(255,255,255,0.1)', border: 'none', color: 'var(--text-main)', cursor: 'pointer', borderRadius: '50%', width: '32px', height: '32px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                >
                  <X size={16} />
                </button>
              </div>
              
              <div className="flex justify-between items-center" style={{ marginBottom: '1rem' }}>
                <span style={{ fontSize: '0.875rem', color: 'var(--success)' }}>
                  提示：销量趋势 = 最近两次抓取的评价数 (review_count) 之差 ÷ 1% 留评率估算得出
                </span>
                <button 
                  className="btn"
                  style={{ padding: '0.5rem 1rem', fontSize: '0.875rem', borderRadius: '8px' }}
                  onClick={async () => {
                    try {
                      alert('已触发后台刷新该 SKU 任务，请稍后重新打开弹窗查看最新节点！');
                      await api.post('/tasks/search', {
                        task_type: 'SEARCH',
                        query: selectedSku, // Directly search SKU to refresh it
                        country: 'uae',
                        language: 'en'
                      });
                    } catch (e) {
                      console.error(e);
                    }
                  }}
                >
                  <RefreshCw size={14} /> 立即获取最新数据
                </button>
              </div>
              
              <div style={{ width: '100%', height: '350px' }}>
                {priceHistory.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={priceHistory}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" vertical={false} />
                      <XAxis dataKey="time" stroke="#a1a1aa" fontSize={12} tickLine={false} axisLine={false} />
                      <YAxis yAxisId="left" stroke="#60a5fa" fontSize={12} tickLine={false} axisLine={false} domain={['dataMin - 20', 'dataMax + 20']} />
                      <YAxis yAxisId="right" orientation="right" stroke="#34d399" fontSize={12} tickLine={false} axisLine={false} domain={['dataMin', 'auto']} />
                      <Tooltip content={<CustomTooltip />} />
                      <Line yAxisId="left" type="monotone" dataKey="price" name="实时售价 (AED)" stroke="var(--primary)" strokeWidth={3} dot={{ r: 4, fill: "var(--primary)" }} activeDot={{ r: 6 }} />
                      <Line yAxisId="left" type="monotone" dataKey="original_price" name="原始标价" stroke="var(--text-muted)" strokeDasharray="5 5" strokeWidth={2} dot={false} />
                      <Line yAxisId="right" type="stepAfter" dataKey="review_count" name="累计评价数" stroke="var(--success)" strokeWidth={3} dot={{ r: 4, fill: "var(--success)" }} activeDot={{ r: 6 }} />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center" style={{ height: '100%', justifyContent: 'center', color: 'var(--text-muted)' }}>
                    <RefreshCw className="spin" size={24} />
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <style>{`
        @keyframes spin { 100% { transform: rotate(360deg); } }
        .spin { animation: spin 1s linear infinite; }
        
        @keyframes blink { 50% { opacity: 0; } }
        .blinking-cursor { animation: blink 1s step-end infinite; }
      `}</style>
    </div>
  );
}
