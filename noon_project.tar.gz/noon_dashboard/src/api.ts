import axios from 'axios';

// Create an axios instance pointing to the FastAPI backend
export const api = axios.create({
  baseURL: 'http://localhost:8000/api/v1',
  headers: {
    'Content-Type': 'application/json',
  },
});

export interface Product {
  sku: string;
  title: string;
  brand: string | null;
  category: string | null;
  image_url: string | null;
  product_url: string | null;
  price?: number;
  currency?: string;
  is_express: boolean;
  status: string;
  updated_at: string;
}

export interface Task {
  job_id: string;
  task_type: string;
  query: string;
  status: string;
  result_count: number | null;
  error_message: string | null;
  created_at: string;
}

export interface Stats {
  total_products: number;
  active_products: number;
  total_snapshots: number;
}
